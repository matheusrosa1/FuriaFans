export interface DropMessage {
  id: string;
  author: string;
  content: string;
  timestamp: string;
}